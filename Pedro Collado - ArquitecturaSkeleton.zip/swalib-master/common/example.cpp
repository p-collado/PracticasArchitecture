#include "stdafx.h"
#include "sys.h"
#include "core.h"
#include "font.h"
#include "..\swalib_example\CGame.h"
#include "..\swalib_example\CGameRender.h"


//-----------------------------------------------------------------------------
int Main(void)
{
		CGame game;
		CGameRender render;

		render.RenderInit();
		game.GameInit(render.texsmallball);

	while (!SYS_GottaQuit()) {	// Controlling a request to terminate an application.

		game.GameUpdate();
		render.Draw();
		SYS_Pump();	// Process Windows messages.
		SYS_Sleep(17);	// To force 60 fps
	}
	render.RenderEnd();
	return 0;
}
