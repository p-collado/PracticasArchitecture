﻿#include "NewPosMsg.h"
