﻿#pragma once

#include "../../common/vector2d.h"

class Message
{
public:
    virtual  ~Message();
};
