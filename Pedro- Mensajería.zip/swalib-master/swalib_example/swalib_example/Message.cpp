﻿#include "Message.h"

Message::~Message()
{
    
}
