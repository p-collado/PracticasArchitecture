﻿#pragma once
#include "CollisionMsg.h"

class EntCollisionMsg : public CollisionMsg
{
public:
    EntCollisionMsg(){}
    ~EntCollisionMsg(){}
    vec2 Vel;
    
};
