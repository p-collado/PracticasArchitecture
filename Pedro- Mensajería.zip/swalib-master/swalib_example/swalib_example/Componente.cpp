﻿#include "Componente.h"
