#pragma once

class CGame
{
public:
	void GameInit();
	void GameUpdate(double _elapsed);
	void GameEnd();
};


